package com.cg.ppws.controller;



import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ppws.bean.CSAccount;
import com.cg.ppws.bean.CSTransaction;
import com.cg.ppws.service.CSAccountService;


public class HomeController {


	@Autowired
	CSAccountService servAccount;

	CSAccount account;

	//@PostMapping("newaccount")
		public void newAccount(CSAccount account1) {

			servAccount.addAccount(account1);
		}

	
	public boolean validateLogin(CSAccount account1) {
		account=servAccount.getAccount(account1);

		if(account!=null)
		{
			if(account.getPassword().equals(account1.getPassword())) {
				return true;
			}
			else {
				return false;
			}
		}
		else{
			return false;
		}
	}




	public void depositAmount(double amount,int id)
	{

		account=servAccount.deposit(amount,id);
	}

	

	//@PostMapping("withdrawAmount")
	public void withdrawAmount(double amount)
	{

			account=servAccount.withdraw(amount,account.getId());
		
	}


	//@PostMapping("bankToWallet")
	public void bankToWallet(double amount,int id)
	{
		
		
			account=servAccount.bankToWallet(amount,id);

			
		
	}
	
	//@RequestMapping("payFromWallet")
	public String payFromWallet(Model model)
	{

		return "payFromWallet";
	}


	//@PostMapping("walletToWallet")
	public void walletToWallet(int id, int receiver, double amount)
	{
		
			account=servAccount.walletToWallet(amount,id,receiver);
			
	}
	



	//@PostMapping("transferBackToBank")
	public void walletToBank(int id, double amount)
	{
		account=servAccount.walletToBank(amount,account.getId());
	}
	
	//@RequestMapping("transaction")
	public List<CSTransaction> transaction(int id) {

		List<CSTransaction> list=servAccount.getTransactions(id);
		
		return list;
	}


	public CSAccount getAccount(int acId) {

		return servAccount.getAccount(acId);
	}


	public Double showAccountBalance(int acId) {

		return servAccount.getAccount(acId).getBalance();
	}


	public Double showWalletBalance(int acId) {

		return servAccount.getAccount(acId).getWallet();
	}


	public Iterable<CSAccount> getAll() {
		// TODO Auto-generated method stub
		return servAccount.getAll();
	}
	
	
}
