package com.cg.ppws.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.ppws.bean.CSAccount;

@Repository
public interface CSAccountRepository extends CrudRepository<CSAccount,Integer>{

}
