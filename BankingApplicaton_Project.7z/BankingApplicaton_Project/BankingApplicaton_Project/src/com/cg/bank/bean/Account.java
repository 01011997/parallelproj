package com.cg.bank.bean;

public class Account {
	private String Username;
	private int Account_number;
	private int Balance;
	private String mobileNo;
	
	public Account(String username, String password, int account_number, int balance, String mobileNo) 
	{
		super();
		Username = username;
		
		Account_number = account_number;
		Balance = balance;
		this.mobileNo = mobileNo;
	}
	
	public Account(String username, String mobileNo,int balance) {
		Username = username;
		
		this.mobileNo = mobileNo;
		Balance = balance;
	}


	

	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}

	
	public int getAccount_number() {
		return Account_number;
	}
	public void setAccount_number(int account_number) {
		Account_number = account_number;
	}
	public int getBalance() {
		return Balance;
	}
	public void setBalance(int amountAfterWithdraw) {
		Balance = amountAfterWithdraw;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "Account [Username=" + Username + " " + ", Account_number=" + Account_number
				+ ", Balance=" + Balance + ", mobileNo=" + mobileNo + "]";
	}
	
	public String toString1() {
		return "Account [Username=" + Username + " mobileNo=" + mobileNo + "]";
	}
	

	

}
