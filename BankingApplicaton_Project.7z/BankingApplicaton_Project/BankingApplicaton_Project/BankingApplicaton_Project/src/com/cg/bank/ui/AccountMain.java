package com.cg.bank.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.AccountException;
import com.cg.bank.service.AccountServiceImpl;
import com.cg.bank.service.IAccountService;

public class AccountMain {
	public static void main(String[] args) throws AccountException {
		Scanner scan=null;
		Scanner scan1=null;
		
		IAccountService service= new AccountServiceImpl();
		Account account=null;
		String ContinueChoice="";
		do {
			System.out.println("Welcome to Bank App");	
			System.out.println("1.Create Account\n2.Show Balance\n3.Deposite\n4.Withdraw\n5.Fund Transfer\n6.Print Transaction");
		
			int choice =0;
			boolean choiceFlag=false;
			do {
				scan=new Scanner(System.in);
				System.out.println("Enter your Choice");
				try {
					choice=scan.nextInt();
					choiceFlag=true;
					switch(choice) {
					case 1:
				             	String Username="";
									boolean UsernameFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter your name");
										try {
										Username=scan1.nextLine();
										service.validateUserName(Username);	
										UsernameFlag=true;
										break;
										}catch(AccountException e) {
											UsernameFlag=false;
											System.out.println(e.getMessage());
										}
									}while(!UsernameFlag);
						/*
						 * String Password=""; boolean PasswordFlag=false; do { scan1=new
						 * Scanner(System.in); System.out.println("Enter Password"); try {
						 * Password=scan1.nextLine(); service.validatePassword(Password);
						 * PasswordFlag=true; break; }catch(AccountException e) { PasswordFlag=false;
						 * System.out.println(e.getMessage()); } }while(!PasswordFlag);
						 */
									String MobileNo="";
									boolean  MobileNoFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Mobile number");
										try {
											 MobileNo=scan1.nextLine();
										service.validateMobileNo(MobileNo);	
										 MobileNoFlag=true;
										break;
										}catch(AccountException e) {
											 MobileNoFlag=false;
											System.out.println(e.getMessage());
										}
									}while(! MobileNoFlag);
									
									int Balance=0;
									boolean  BalanceFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter the amount ");
										Balance=scan1.nextInt();

										 BalanceFlag=true;
										 break;
									}while(!  BalanceFlag);
									
									Account acc=new Account(Username,MobileNo, Balance);
									int Account_number=(int) (Math.random()*1000*1000);
									//account.setAccount_number(Account_number);
									System.out.println("Account created Successfully with Account number"+ Account_number);
									acc.setAccount_number(Account_number);
									
									service.addnewAccount(acc);
									break;
								case 2:
									int Accno = 0;
									boolean Account_numberFlag = false;
									do {
										scan = new Scanner(System.in);
										System.out.println("Enter Account number");
										try {
											Accno = scan.nextInt();
											service.validateAccount_number(Accno);						
											Account_numberFlag = true;
											break;

										} catch (InputMismatchException e) {
											Account_numberFlag = false;
											System.err.println(e.getMessage());
										} catch (AccountException e) {
											System.err.println(e.getMessage());
										}

									} while (!Account_numberFlag);
									service.ShowBalance(Accno);
									System.out.println(service.ShowBalance(Accno));
									break;
								
								case 3:
									//For Deposit
									System.out.println("Enter Account Number..");
									int Accnum=scan.nextInt();
									System.out.println("Enter the amount for deposit");
									double amount=scan.nextDouble();
									double amountAfterDeposite=service.deposite(Accnum,amount);
									System.out.println("New Balance: "+amountAfterDeposite);
									break;
								case 4:
									//For Deposit
									System.out.println(" Enter your account number");
									int Account_num=scan.nextInt();
									System.out.println(" Enter the amount for deposit");
									double amountwithdraw=scan.nextDouble();
									double amountAfterDeposite1=service.withdraw(Account_num,amountwithdraw);
									System.out.println("New Balance: "+amountAfterDeposite1);
									break;	
									
									
								case 5:
									
									//Fund Transfer
									int account_number,reciever_account_number;
									System.out.println("Enter Account Number: ");
									account_number=scan.nextInt();
									System.out.println("Enter Receiver Account Number: ");
									reciever_account_number=scan.nextInt();
									System.out.println("Enter Amount to Transfer: ");
									amount=scan.nextInt();
									String str=service.fundTransfer(account_number,reciever_account_number,amount);
									System.out.println(str);
									break;
									
							
									
									
					}
					
				}catch(InputMismatchException e) {
					choiceFlag=false;
					System.err.println("Please Enter digits");
				}
				
			}while(!choiceFlag);
			scan=new Scanner(System.in);
			System.out.println("Do you want to continue again [yes/no]");
			ContinueChoice=scan.nextLine();
			
		}while(ContinueChoice.equalsIgnoreCase("yes"));
		scan.close();
		scan1.close();
		
	}

}
