package com.cg.bank.dao;

import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.AccountException;

public interface IAccountDAO {

	Object ShowBalance(int account_number1) throws AccountException ;

	double deposite(int Account_number11, double amount) throws AccountException;

	double withdraw(int account_number111, double amountwithdraw) throws AccountException;
	public void addnewAccount(Account a);



}
