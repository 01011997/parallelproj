package com.cg.bank.dao;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.bean.Wallet;
import com.cg.bank.exception.AccountException;



public class AccountDAOImpl implements IAccountDAO {
	Map<Integer,Account>account=new HashMap<Integer,Account>();
	Map<Integer,Wallet>wallet=new HashMap<Integer,Wallet>();
List<Transaction>transaction=new ArrayList<Transaction>();
Wallet w=null;
	

	public void addnewAccount(Account a){
		account.put(a.getAccount_number(), a);	
		w=new Wallet(a.getAccount_number(), 0);
		wallet.put(a.getAccount_number(), w);
		System.out.println(account);
		
	}
	@Override
	public int ShowBalance(int account_number1) {
		int Balance=0;
		for(Account acc:account.values())
		{
			if(acc.getAccount_number()==account_number1)
			{
				Balance=acc.getBalance();
				break;
			}
			else
				System.out.println("Please Enter Proper Account no.");
			
		}
		
			return Balance;
	}


	@Override
	public double deposite(int Account_number11, double deposited_amount) throws AccountException {
		double amountAfterDeposite=0;
		for(Account acc:account.values()) {
			System.out.println("account number:  "+ acc.getAccount_number());
			if(acc.getAccount_number()==Account_number11) {
				amountAfterDeposite=acc.getBalance()+deposited_amount;
				acc.setBalance((int) amountAfterDeposite);
				Transaction trans=new Transaction(Account_number11, deposited_amount, acc.getBalance(), LocalDate.now());
				transaction.add(trans);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		return amountAfterDeposite;
	}
	@Override
	public double withdraw(int account_number111, double amountwithdraw) throws AccountException {
		double amountAfterWithdraw=0;
		for(Account acc:account.values()) {
			System.out.println("account number:  "+ acc.getAccount_number());
			if(acc.getAccount_number()==account_number111) {
				amountAfterWithdraw=acc.getBalance()-amountwithdraw;
				acc.setBalance((int) amountAfterWithdraw);
				Transaction trans=new Transaction(account_number111, amountwithdraw, acc.getBalance(), LocalDate.now());
				transaction.add(trans);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		return amountAfterWithdraw;
	}
	@Override
	public String fundTransfer(int account_number, int reciever_account_number, double amount) {
	
			int amountAfterWithdraw;
			int amountAfterDeposit;
			boolean wrongacc=false;
			for(Account acc:account.values()) {
				if(acc.getAccount_number()==account_number) {
					 amountAfterWithdraw= (int) (acc.getBalance()-amount);
					acc.setBalance( amountAfterWithdraw);
					wrongacc=false;
					Transaction trans=new Transaction( account_number, amount,acc.getBalance(), LocalDate.now());
					transaction.add(trans);
					break;
				}
				else
					wrongacc=true;
			}
			for(Account acc:account.values()) {
				if(acc.getAccount_number()==reciever_account_number) {
				amountAfterDeposit = (int) (acc.getBalance()+amount);
					acc.setBalance(amountAfterDeposit);
					wrongacc=false;
					Transaction trans=new Transaction( reciever_account_number, amount,acc.getBalance(), LocalDate.now());
					transaction.add(trans);
					break;
				}
				else
					wrongacc=true;
			}
			
			if(wrongacc==true)
			{
				System.out.println("Account does not exist");
			}
			
			return "Transfered";
	}
	@Override
	public List<Transaction> printtransaction(int account_number) {

			List<Transaction> l=new ArrayList<Transaction>();
			
			for(Transaction t:transaction)
				if(t.getAccount_number()==account_number) {
					l.add(t);
				}
		
		
		return l;
	}
	@Override
	public String accounttowallet(int accno, int amt) {
		// TODO Auto-generated method stub
		int Wallet_Balance=0;
		int amountAfterWithdraw=0;
		for(Account acc:account.values()) {
			if(acc.getAccount_number()==accno) {
				 amountAfterWithdraw=(int) (acc.getBalance()-amt);
				acc.setBalance( (int) amountAfterWithdraw);
	
			}
		}
		for(Wallet w:wallet.values()) {
			if(w.getAccount_no()==accno) {
				Wallet_Balance= (int)(w.getWallbal()+amt);
				w.setWallbal((int)Wallet_Balance);

				break;
			}
			
		
			
	}
	
		return "transfered";
		
		
	}
	@Override
	public String wallettoaccount(int acn0, int amtt) {
		// TODO Auto-generated method stub
		int Wallet_Balance=0;
		int amountAfterDeposite=0;
		
		for(Wallet w:wallet.values()) {
			if(w.getAccount_no()==acn0) {
				Wallet_Balance= (int)(w.getWallbal()-amtt);
				w.setWallbal(Wallet_Balance);
				
				break;
			}
			
		
			
	}
		for(Account acc:account.values()) {
			if(acc.getAccount_number()==acn0) {
				amountAfterDeposite=(int) (acc.getBalance()+amtt);
				acc.setBalance( (int) amountAfterDeposite);
				break;
			}
		}
	
		return "transfered";
		
		
	}
	@Override
	public Object showwalletbal(int accno) {
		// TODO Auto-generated method stub
		int wallbal = 0;
		for(Wallet wal:wallet.values())
		{
			if(wal.getAccount_no()==accno)
			{
				wallbal=wal.getWallbal();
				break;
			}
			else
				System.out.println("Please Enter Proper Account no.");
		}
		
			return wallbal;
	}
	}