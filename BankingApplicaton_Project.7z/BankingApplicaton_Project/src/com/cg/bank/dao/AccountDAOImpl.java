package com.cg.bank.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.bean.Wallet;
import com.cg.bank.exception.AccountException;

public class AccountDAOImpl implements IAccountDAO {
	Map<Integer,Account>account=new HashMap<Integer,Account>();
	Map<Integer,Wallet>wallet=new HashMap<Integer,Wallet>();
	Map<Integer,Transaction>transaction=new HashMap<Integer,Transaction>();

	public void addnewAccount(Account a){
		account.put(a.getAccount_number(), a);		
		System.out.println(account);
		
	}
	@Override
	public Map<Integer, Account> ShowBalance(int account_number1) {
		// TODO Auto-generated method stub
		return account;
	}


	@Override
	public double deposite(int Account_number11, double amount) throws AccountException {
		double amountAfterDeposite=0;
		for(Account ac:account.values()) {
			System.out.println("account number:  "+ ac.getAccount_number());
			if(ac.getAccount_number()==Account_number11) {
				amountAfterDeposite=ac.getBalance()+amount;
				ac.setBalance(amountAfterDeposite);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		return amountAfterDeposite;
	}

	@Override
	public double withdraw(int account_number111, double amountwithdraw) throws AccountException {
		double amountAfterWithdraw=0;
		for(Account ac:account.values()) {
			System.out.println("account number:  "+ ac.getAccount_number());
			if(ac.getAccount_number()==account_number111) {
				amountAfterWithdraw=ac.getBalance()-amountwithdraw;
				ac.setBalance(amountAfterWithdraw);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		return amountAfterWithdraw;
	}

	

	
	
	}

	

