package com.cg.bank.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.bank.bean.Account;
import com.cg.bank.dao.AccountDAOImpl;
import com.cg.bank.dao.IAccountDAO;
import com.cg.bank.exception.AccountException;


public class AccountServiceImpl implements IAccountService {
	IAccountDAO dao=new AccountDAOImpl();

	@Override
	public void validateUserName(String username) throws AccountException {
		String NameRegex="[A-Z]{1}[a-z]{2,8}";
		if(Pattern.matches(NameRegex, username)==false) {
		throw new AccountException("Username start with capital letter");	
	}
	}

	@Override
	public void validatePassword(String password) throws AccountException {
		String PasswordRegex="[0-9]{5}";
		if(Pattern.matches(PasswordRegex, password)==false) {
		throw new AccountException("Password contains 5 digits");		
	}
	}

	@Override
	public void validateMobileNo(String mobileNo) throws AccountException {
		String MobileRegex="[9|8|7]{1}[0-9]{9}";
		if(Pattern.matches(MobileRegex, mobileNo)==false) {
		throw new AccountException("Mobile number should contains 10 digits");
		
	}

	}

	@Override
	public void validateAccount_number(int account_number) throws AccountException {
		String AccountRegEx = "[0-9]+";
		if (Pattern.matches(AccountRegEx, String.valueOf(account_number)) == false) {
			throw new AccountException("orderid should contain only digits");
		}	
	}
	public void addnewAccount(Account a){
	dao.addnewAccount(a);
		
	}

	public Map<Integer, Account> ShowBalance(int account_number1) throws AccountException {
		return (Map<Integer, Account>) dao.ShowBalance(account_number1);
		
	}
	@Override
	public double deposite(int Account_number11, double amount) throws AccountException {
		// TODO Auto-generated method stub
		return dao.deposite(Account_number11,amount);
	}
	@Override
	public double withdraw(int account_number111, double amountwithdraw) throws AccountException {
		// TODO Auto-generated method stub
		return dao.withdraw(account_number111,amountwithdraw);
	}

	
	


	}
