package com.cg.bank.bean;

public class Account {
	private String Username;
	private String Password;
	private int Account_number;
	private Double Balance;
	private String mobileNo;
	
	public Account(String username, String password, int account_number, Double balance, String mobileNo) 
	{
		super();
		Username = username;
		Password = password;
		Account_number = account_number;
		Balance = balance;
		this.mobileNo = mobileNo;
	}
	
	public Account(String username, String password, String mobileNo,Double balance) {
		Username = username;
		Password = password;
		this.mobileNo = mobileNo;
		Balance = balance;
	}


	

	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public int getAccount_number() {
		return Account_number;
	}
	public void setAccount_number(int account_number) {
		Account_number = account_number;
	}
	public Double getBalance() {
		return Balance;
	}
	public void setBalance(Double balance) {
		Balance = balance;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "Account [Username=" + Username + ", Password=" + Password + ", Account_number=" + Account_number
				+ ", Balance=" + Balance + ", mobileNo=" + mobileNo + "]";
	}
	
	public String toString1() {
		return "Account [Username=" + Username + ", Password=" + Password + ",  mobileNo=" + mobileNo + "]";
	}
	

	

}
