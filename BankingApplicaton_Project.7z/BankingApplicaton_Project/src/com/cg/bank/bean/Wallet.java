package com.cg.bank.bean;

public class Wallet {
private int Account_number;
private String wallet_Balance;


public Wallet(int account_number, String wallet_Balance) {
	super();
	Account_number = account_number;
	this.wallet_Balance = wallet_Balance;
}


public String getWallet_Balance() {
	return wallet_Balance;
}


public void setWallet_Balance(String wallet_Balance) {
	this.wallet_Balance = wallet_Balance;
}


public int getAccount_number() {
	return Account_number;
}


public void setAccount_number(int account_number) {
	Account_number = account_number;
}


@Override
public String toString() {
	return "Wallet [Account_number=" + Account_number + ", wallet_Balance=" + wallet_Balance + "]";
}



}
