package com.cg.bank.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.AccountException;
import com.cg.bank.service.AccountServiceImpl;
import com.cg.bank.service.IAccountService;

public class AccountMain {
	public static void main(String[] args) throws AccountException {
		Scanner scan=null;
		Scanner scan1=null;
		
		IAccountService service= new AccountServiceImpl();
		Account account=null;
		String ContinueChoice="";
		do {
			System.out.println("******** Welcome to Mobile App *********");	
			System.out.println("*******************************");
			System.out.println("1.Create Account\n2.Show Balance\n3.Deposite\n4.Withdraw\n5.Fund Transfer\n6.Print Transaction");
			System.out.println("*******************************");
			
			int choice =0;
			boolean choiceFlag=false;
			do {
				scan=new Scanner(System.in);
				System.out.println("Enter your Choice");
				try {
					choice=scan.nextInt();
					choiceFlag=true;
					switch(choice) {
					case 1:
				             	String Username="";
									boolean UsernameFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Username");
										try {
										Username=scan1.nextLine();
										service.validateUserName(Username);	
										UsernameFlag=true;
										break;
										}catch(AccountException e) {
											UsernameFlag=false;
											System.out.println(e.getMessage());
										}
									}while(!UsernameFlag);
									String Password="";
									boolean PasswordFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Password");
										try {
										Password=scan1.nextLine();
										service.validatePassword(Password);	
										PasswordFlag=true;
										break;
										}catch(AccountException e) {
											PasswordFlag=false;
											System.out.println(e.getMessage());
										}
									}while(!PasswordFlag);
									String MobileNo="";
									boolean  MobileNoFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Mobile number");
										try {
											 MobileNo=scan1.nextLine();
										service.validateMobileNo(MobileNo);	
										 MobileNoFlag=true;
										break;
										}catch(AccountException e) {
											 MobileNoFlag=false;
											System.out.println(e.getMessage());
										}
									}while(! MobileNoFlag);
									
									Double Balance=0d;
									boolean  BalanceFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Minimum balance");
										Balance=scan1.nextDouble();

										 BalanceFlag=true;
										 break;
									}while(!  BalanceFlag);
									
									Account a=new Account(Username, Password,MobileNo,Balance);
									int Account_number=(int) (Math.random()*1000*1000);
									//account.setAccount_number(Account_number);
									System.out.println("Account created Successfully with Account number"+ Account_number);
									a.setAccount_number(Account_number);
									
									service.addnewAccount(a);
									break;
								case 2:
									int Account_number1 = 0;
									boolean Account_numberFlag = false;
									do {
										scan = new Scanner(System.in);
										System.out.println("Enter Account number");
										try {
											Account_number1 = scan.nextInt();
											service.validateAccount_number(Account_number1);						
											Account_numberFlag = true;
											break;

										} catch (InputMismatchException e) {
											Account_numberFlag = false;
											System.err.println(e.getMessage());
										} catch (AccountException e) {
											System.err.println(e.getMessage());
										}

									} while (!Account_numberFlag);
									service.ShowBalance(Account_number1);
									System.out.println(service.ShowBalance(Account_number1));
									break;
								
								case 3:
									//For Deposit
									System.out.println("You want to deposit amount in your account...\nEnter Account Number..");
									int Account_number11=scan.nextInt();
									System.out.println("Now enter the amount for deposit");
									double amount=scan.nextDouble();
									double amountAfterDeposite=service.deposite(Account_number11,amount);
									System.out.println("New Balance: "+amountAfterDeposite);
									break;
								case 4:
									//For Deposit
									System.out.println("You want to withdraw from your account\n Enter your account number");
									int Account_number111=scan.nextInt();
									System.out.println("Now enter the amount for deposit");
									double amountwithdraw=scan.nextDouble();
									double amountAfterDeposite1=service.withdraw(Account_number111,amountwithdraw);
									System.out.println("New Balance: "+amountAfterDeposite1);
									break;	
						
									
					}
					
				}catch(InputMismatchException e) {
					choiceFlag=false;
					System.err.println("Please Enter digits");
				}
				
			}while(!choiceFlag);
			scan=new Scanner(System.in);
			System.out.println("Do you want to continue again [yes/no]");
			ContinueChoice=scan.nextLine();
			
		}while(ContinueChoice.equalsIgnoreCase("yes"));
		scan.close();
		scan1.close();
		
	}

}
