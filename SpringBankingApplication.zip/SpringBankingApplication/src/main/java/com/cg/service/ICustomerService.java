package com.cg.service;

import java.util.List;

import com.cg.entity.Customer;

public interface ICustomerService {
	public Customer createAcc(Customer customer);
	public double withdrawMoney(String mobNo, double amt);
	public void depositMoney(String mobNo, Double amt);
	public Customer updateAcc(Customer customer);
	public void fundTransfer(String mobNo1, String mobNo2,double amt);
	public List<Customer>viewCustomers();
	public Customer findByMobNo(String customer);
	void deleteByMobNo(String mobNo);
}
