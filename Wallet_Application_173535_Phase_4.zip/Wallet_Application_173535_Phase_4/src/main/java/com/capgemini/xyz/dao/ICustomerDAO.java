package com.capgemini.xyz.dao;

import java.util.List;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.TransactionDatas;
import com.capgemini.xyz.exception.CustomerExists;
import com.capgemini.xyz.exception.CustomerNotFoundException;
import com.capgemini.xyz.exception.InsufficientBalanceException;

public interface ICustomerDAO {

	Customer createCustomer(Customer customer) throws CustomerExists;

	String withDraw(Customer customer, double amount)	throws InsufficientBalanceException;

	String deposit(Customer customer, double amount) throws CustomerNotFoundException;

	Customer checkUser(String username, String password) throws CustomerNotFoundException;

	List<TransactionDatas> printTransaction(Customer customer);

	Customer isValidUser(String mobileNumber) throws CustomerNotFoundException;
	
	double checkBalance(Customer customer);
	
	long CID = 1000;
	int TID = 1;
}
