package com.capgemini.xyz.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.exception.CustomerExists;
import com.capgemini.xyz.exception.CustomerNotFoundException;
import com.capgemini.xyz.service.CustomerService;
import com.capgemini.xyz.service.CustomerServiceInterface;

public class DepositTest {
	CustomerServiceInterface service = null;

	@Before
	public void setUp() throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		service = (CustomerServiceInterface) ctx.getBean("service");
	}

	// right inputs
	@Test
	public void checkDeposit() {
		try {
			Customer customer = service.checkUser("8286703935", "password");
			String result = service.deposit(customer, 2000);
			System.out.println(result);
			assertNotNull(result);
		}catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print no user as user don't exists in console
	@Test
	public void checkDeposit2() {
		try {
			Customer customer = service.checkUser("11111935", "password");
			String result = service.deposit(customer, 9000);
			System.out.println(result);
			assertNotNull(result);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
