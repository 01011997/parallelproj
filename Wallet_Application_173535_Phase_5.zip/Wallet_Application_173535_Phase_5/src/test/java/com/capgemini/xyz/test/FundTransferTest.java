package com.capgemini.xyz.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.exception.CustomerExists;
import com.capgemini.xyz.exception.CustomerNotFoundException;
import com.capgemini.xyz.exception.InsufficientBalanceException;
import com.capgemini.xyz.service.CustomerService;
import com.capgemini.xyz.service.CustomerServiceInterface;

public class FundTransferTest {

	CustomerServiceInterface service = null;

	@Before
	public void setUp() throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		service = (CustomerServiceInterface) ctx.getBean("service");
	}

	// right inputs
	@Test
	public void checkFundTransfer() {
		try {
			Customer customer = service.checkUser("8286703935", "password");
			Customer customer2 = service.isValidUser("9892622745");
			String[] result = service.fundTransfer(customer,customer2, 1000);
			for (String r : result) 
				System.out.println(r);
			assertNotNull(result);
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print insufficient balance in console
	@Test
	public void checkFundTransfer2() {
		try {
			Customer customer = service.checkUser("8286703935", "password");
			Customer customer2 = service.isValidUser("9892622745");
			String[] result = service.fundTransfer(customer,customer2, 9000000);
			assertNotNull(result);
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	//wrong inputs
	//should give no user found
	@Test
	public void checkFundTransfer3() {
		try {
			Customer customer = service.checkUser("8286703935", "password");
			Customer customer2 = service.isValidUser("111112745");
			String[] result = service.fundTransfer(customer,customer2, 2000);
			assertNotNull(result);
		}catch (CustomerNotFoundException e) {
				System.out.println(e.getMessage()); 
		}catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	@After
	public void destroy() throws Exception {
		service = null;
	}
}
