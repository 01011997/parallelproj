package com.cg.main;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.dto.Customer;
import com.cg.exception.BMSException;
import com.cg.service.BankService;
import com.cg.service.BankServiceImpl;

public class MainUI {

	public static void main(String[] args) 
	
	{
		Scanner scanner = null;
		BankService service=new BankServiceImpl();
		Customer cust=null;
		String continueChoice = "";
		
		
		do {

			System.out.println("****** Wallet ******");
			System.out.println("1:Create Account");
			System.out.println("2:Show Balance");
			System.out.println("3:Deposite");
			System.out.println("4:Withdraw");
			System.out.println("5:Fund Transfer");
			System.out.println("6:Print Transaction");
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					switch(choice)
					{
					
					case 1:
						String customername = "";
						boolean custNameFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter the name of customer");
							try {
								customername = scanner.nextLine();
								service.validateName(customername);
								custNameFlag = true;
								break;
							} catch (BMSException e) {
								custNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custNameFlag);
					
						String customermobno = "";
						boolean custmobnoFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter the mobile number of customer");
							try {
								customermobno = scanner.nextLine();
								service.validatemobno(customermobno);
								custmobnoFlag = true;
								break;
							} catch (BMSException e) {
								custmobnoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custmobnoFlag);
						
						String aadharno = "";
						boolean aadharnoFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter 12 digit aadhar card no.");
							try {
								aadharno = scanner.nextLine();
								service.validateaadharno(aadharno);
								aadharnoFlag = true;
								break;
							} catch (BMSException e) {
								aadharnoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!aadharnoFlag);
						
						int accno = (int) (Math.random() * 1000000000);
						//cust.setAccno(accno);
						System.out.println("Account Created Sucessfully with account no: "+accno);
						System.out.println("Enter the password");
						String password=scanner.nextLine();
						System.out.println("Enter the Amount ");
						int amount=scanner.nextInt();
						break;
					
					case 2:
						//For Display
						System.out.println("Enter the account no");
						 accno=scanner.nextInt();
						System.out.println("Accounts Detail: ");
						
						System.out.println(service.displayAccountDetails());
						break;
						
					case 3:
						//for Deposite
						System.out.println("\nEnter Account Number..");
						 accno=scanner.nextInt();
						 System.out.println("Now enter the amount for deposit");
						 amount=scanner.nextInt();
						 int amountAfterDeposit=service.deposite(accno,amount);
							System.out.println("New Balance:"+amountAfterDeposit);
							break;
							
							
					case 4:
						//for withdraw
						System.out.println("Enter Account Number..");
						 accno=scanner.nextInt();
						System.out.println("Enter the amount for Withdrawal");
						int amountWithdrawal=scanner.nextInt();
						int amountAfterWithdraw=service.withdraw(accno,amountWithdrawal);
						System.out.println("New Balance: "+amountAfterWithdraw);
						break;
						
						
						
					
					
					}
				
				
				
				
				
				
				
				
				
				
				
				

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				} catch (BMSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}while(!choiceFlag);

			
			
			
			

			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();
		}while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
		
		

	}

}
