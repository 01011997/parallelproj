package com.cg.exception;

public class BMSException extends Exception
{
	public BMSException(String message) {
		super(message);
}
}
