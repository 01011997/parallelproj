package com.cg.dto;

public class Customer 
{
private String name;
private String mobno;
private String Aadharno;
private double accno;
//private Integer deposite;
private Integer balance;
//private Integer withdraw;
private String Password;
public Customer(String name, String mobno, String aadharno, double accno, Integer deposite, Integer balance,
		Integer withdraw, String password) {
	super();
	this.name = name;
	this.mobno = mobno;
	Aadharno = aadharno;
	this.accno = accno;
	this.balance = balance;
	/*this.deposite = deposite;
	
	this.withdraw = withdraw;*/
	Password = password;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
public String getName() {
	return name;
}
@Override
public String toString() {
	return "Customer [name=" + name + ", mobno=" + mobno + ", Aadharno=" + Aadharno + ", accno=" + accno + ", deposite="
			+   ", balance="  + ", withdraw="+ ", Password=" + Password + "]";
}
public Customer(String name, String mobno, String aadharno, double accno, Integer deposite, Integer balance,
		Integer withdraw) {
	super();
	this.name = name;
	this.mobno = mobno;
	Aadharno = aadharno;
	this.accno = accno;
	/*this.deposite = deposite;
	this.balance = balance;
	this.withdraw = withdraw;*/
}
public void setName(String name) {
	this.name = name;
}
public String getMobno() {
	return mobno;
}
public void setMobno(String mobno) {
	this.mobno = mobno;
}
public String getAadharno() {
	return Aadharno;
}
public void setAadharno(String aadharno) {
	Aadharno = aadharno;
}
public double getAccno() {
	return accno;
}
public void setAccno(double accno) {
	this.accno = accno;
}
public Integer getBalance() {
	return balance;
}
public void setBalance(Integer balance) {
	this.balance = balance;
}
/*public Integer getDeposite() {
	return deposite;
}
public void setDeposite(Integer deposite) {
	this.deposite = deposite;
}


public Integer getWithdraw() {
	return withdraw;
}*/
/*public void setWithdraw(Integer withdraw) {
	this.withdraw = withdraw;
}*/

}
