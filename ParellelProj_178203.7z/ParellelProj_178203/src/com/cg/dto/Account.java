package com.cg.dto;

public class Account 
{
private int amount;
 private int deposite;
private int balance;
private int withdraw;
private double accno;
public Account(int amount, int deposite, int balance, int withdraw, int accno) {
	super();
	this.amount = amount;
	this.deposite = deposite;
	this.balance = balance;
	this.withdraw = withdraw;
	this.accno = accno;
}
public double getAccno() {
	return accno;
}
public void setAccno(int accno) {
	this.accno = accno;
}
public Account(int amount, int deposite, int balance, int withdraw) {
	super();
	this.amount = amount;
	this.deposite = deposite;
	this.balance = balance;
	this.withdraw = withdraw;
}
@Override
public String toString() {
	return "Account [amount=" + amount + ", deposite=" + deposite + ", balance=" + balance + ", withdraw=" + withdraw
			+ ", accno=" + accno + "]";
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}
public int getDeposite() {
	return deposite;
}
public void setDeposite(int deposite) {
	this.deposite = deposite;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}
public int getWithdraw() {
	return withdraw;
}
public void setWithdraw(int withdraw) {
	this.withdraw = withdraw;
}

}
