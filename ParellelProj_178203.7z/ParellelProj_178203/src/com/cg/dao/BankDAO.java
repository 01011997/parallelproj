package com.cg.dao;

import java.util.Map;

import com.cg.dto.Customer;
import com.cg.exception.BMSException;
public interface BankDAO {

	Map<Double, Customer> displayAccountDetails() throws BMSException;

	int deposite(int accno, int amount);

	int withdraw(int acc, int amountWithdrawal);
	
	
	

}
