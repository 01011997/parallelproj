package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.dto.Account;
import com.cg.dto.Customer;
import com.cg.exception.BMSException;




public class BankDAOImpl implements BankDAO {

	static 	Map<Double,Customer>cust=new HashMap<Double,Customer>();

	static 	Map<Double,Account>acc=new HashMap<Double,Account>();
	

	public void addHistory(Account account) {
		acc.put(account.getAccno(),account);
	}
	
	@Override
	public Map<Double, Customer> displayAccountDetails() throws BMSException {
		// TODO Auto-generated method stub
		return cust;
	}

	@Override
	public int deposite(int accno, int amount) {
		int amountAfterDeposit=0;
		for(Account o:acc.values()) 
		{
			System.out.println("account number:  "+ o.getAccno());
			if(o.getAccno()==accno) 
			{
				amountAfterDeposit=o.getBalance()+amount;
				o.setBalance(amountAfterDeposit);
			
			}
			else
			{
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		return amountAfterDeposit;
	}

	@Override
	public int withdraw(int accno, int amountWithdrawal) {
		int amountAfterWithdraw=0;
		for(Account o:acc.values()) {
			if(o.getAccno()==accno) {
				 amountAfterWithdraw=o.getBalance()-amountWithdrawal;
				o.setBalance( amountAfterWithdraw);
			
			}
			else{
				System.out.println("Enter Proper Account Number..");
			}
		}
		return amountAfterWithdraw;
	}

	}
	
	


