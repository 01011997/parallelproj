package com.cg.service;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.dao.BankDAO;
import com.cg.dao.BankDAOImpl;
import com.cg.dto.Customer;
import com.cg.exception.BMSException;


public class BankServiceImpl  implements BankService {
	
	BankDAO dao=new BankDAOImpl();

	@Override
	public void validateName(String customername) throws BMSException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{3,15}";
		if (!Pattern.matches(nameRegEx, customername)) {
			throw new BMSException("first letter should be capital and length must be in between 5 to 10");
		}
		
	}

	@Override
	public void validatemobno(String customermobno) throws BMSException {
		String phoneRegEx = "[7|8|9]{1}[0-9]{9}";
		if (Pattern.matches(phoneRegEx, customermobno) == false) {
			throw new BMSException("mobile number should contain exactly 10 digits and it should start with 7/8/9");
		}

	
	}

	@Override
	public void validateaadharno(String aadharno) throws BMSException {
		String aadharRegx="[0-9]{12}";
		if(Pattern.matches(aadharRegx, aadharno)==false) {
			throw new BMSException("Aadhar no.should contain only 12 digits");

		}
		
	}

	@Override
	public Map<Double, Customer> displayAccountDetails() throws BMSException {
		// TODO Auto-generated method stub
		return dao.displayAccountDetails();
	}

	@Override
	public int deposite(int accno, int amount) {
		// TODO Auto-generated method stub
		int amountAfterDeposit=dao.deposite(accno,amount);
		return amountAfterDeposit;
	}

	@Override
	public int withdraw(int accno, int amountWithdrawal) {
		
		int amountAfterWithdrawal=dao.withdraw(accno,amountWithdrawal);
		return amountAfterWithdrawal;
	}

	

}
