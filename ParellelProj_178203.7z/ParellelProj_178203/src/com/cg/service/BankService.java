package com.cg.service;

import java.util.Map;

import com.cg.dto.Customer;
import com.cg.exception.BMSException;



public interface BankService {

	void validateName(String customername)throws BMSException;

	void validatemobno(String customermobno)throws BMSException;

	void validateaadharno(String aadharno)throws BMSException;

	//char[] displayAccountDetails();
	Map<Double,Customer>displayAccountDetails()throws BMSException;

	int deposite(int accno, int amount);

	int withdraw(int accno, int amountWithdrawal);

	

}
