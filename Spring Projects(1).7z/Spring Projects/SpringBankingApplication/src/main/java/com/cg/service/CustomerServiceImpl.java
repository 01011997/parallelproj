package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.CustomerRepository;
import com.cg.entity.Customer;

@Service
public class CustomerServiceImpl implements ICustomerService {
	@Autowired
	CustomerRepository repo;
	
	Customer customer = null;
	
	@Override
	public Customer createAcc(Customer customer) {
		// TODO Auto-generated method stub
		customer.setAccNo((int)(Math.random() * 1000000));
		return repo.save(customer);
	}

	@Override
	public Customer updateAcc(Customer customer) {
		// TODO Auto-generated method stub
		if (customer.getMobNo() == null) {
			customer.setAccNo((int)(Math.random() * 100));
			repo.save(customer);
		}
			else {
				return repo.save(customer);
			}
		return repo.save(customer);
	}

	@Override
	public void deleteByMobNo(String mobNo) {
		// TODO Auto-generated method stub
		repo.deleteById(mobNo);
	}

	@Override
	public List<Customer> viewCustomers() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Customer findByMobNo(String customer) {
		// TODO Auto-generated method stub
		return repo.findById(customer).get();
	}

	@Override
	public double withdrawMoney(String mobNo, double amt) {
		// TODO Auto-generated method stub
		customer=repo.findById(mobNo).get();
		customer.setBalc(customer.getBalc()-amt);
		 repo.save(customer);
		return customer.getBalc();
	}

	@Override
	public void depositMoney(String mobNo, Double amt) {
		// TODO Auto-generated method stub
		customer=repo.findById(mobNo).get();
		customer.setBalc(customer.getBalc()+amt);
		 repo.save(customer);
	}

	@Override
	public void fundTransfer(String mobNo1, String mobNo2, double amt) {
		// TODO Auto-generated method stub
		Customer customer1 = null;
		Customer customer2 = null;
		customer1=repo.findById(mobNo1).get();
		customer2=repo.findById(mobNo2).get();
		customer1.setBalc(customer1.getBalc()-amt);
		repo.save(customer1);
		customer2.setBalc(customer2.getBalc()+amt);
		repo.save(customer2);
	}

}
