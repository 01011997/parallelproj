package com.cg.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
@ControllerAdvice
public class ProductException {
	@ResponseBody
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ExceptionHandler(value = {Exception.class})
	public ErrorDetails handleException(Exception e,HttpServletRequest request) {
		String message=e.getMessage();
		String url=request.getRequestURI().toString();
		return new ErrorDetails(message,url);
	}

}
