package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="customerBank")
@Component
public class Customer implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String custName;
	@Id
	private String mobNo;
	private int accNo;
	private double balc;
	private String address;
	
	public Customer(String custName, String mobNo, int accNo, double balc, String address) {
		super();
		this.custName = custName;
		this.mobNo = mobNo;
		this.accNo = accNo;
		this.balc = balc;
		this.address = address;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public double getBalc() {
		return balc;
	}
	public void setBalc(double balc) {
		this.balc = balc;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int d) {
		this.accNo = d;
	}
	
	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", mobNo=" + mobNo + ", accNo=" + accNo + ", balc=" + balc
				+ ", address=" + address + "]";
	}
	
	
}
