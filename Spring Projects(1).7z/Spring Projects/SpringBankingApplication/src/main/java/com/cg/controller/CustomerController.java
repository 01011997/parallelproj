package com.cg.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Customer;
import com.cg.service.ICustomerService;

@RestController
public class CustomerController {

	@Autowired
	ICustomerService service;
	@Autowired
	Customer cust;
	
	@PostMapping(value="/createAccount",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Customer createCustomer(@RequestBody Customer customer) {
		Customer savedAcc=service.createAcc(customer);
	return savedAcc;
	}
	
	@PutMapping(value="/updateAccount/{mobNo}",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public void updateCustomer(@RequestBody Customer customer) {
		Customer updateProduct=service.updateAcc(customer);
		
	}
	
	@PostMapping(value="/deposit/{mobNo}/{amt}")
	public String deposit(@PathVariable String mobNo,@PathVariable double amt) {
		service.depositMoney(mobNo, amt);
		return "Transaction Successfull "+amt;
	}
	
	@PostMapping(value = "/withdraw/{mobNo}/{amt}")
	public String withdraw(@PathVariable String mobNo,@PathVariable double amt) {
		//System.out.println(Mobile_no+"--"+amount.doubleValue());
		service.withdrawMoney(mobNo, amt);
		return "Transaction Successfull "+amt;
		}
	
	@DeleteMapping("/deleteByMobNo/{mobNo}")
	public String deleteById(@PathVariable String mobNo) {
		service.deleteByMobNo(mobNo);
		return mobNo +"/n"+"Account Deleted";
	}
	
	@GetMapping("/viewAccounts")
	public List<Customer> viewCustomers(){
		return service.viewCustomers();
	}
	
	@GetMapping("/findbyproductid/{id}")
	public Customer findById(@PathVariable String mobNo) {
		return service.findByMobNo(mobNo);
	}
	
	@PostMapping("/fundTransfer/{mobNo1}/{mobNo2}/{amt}")
	public String fundTransfer(@PathVariable String mobNo1,@PathVariable String mobNo2, @PathVariable double amt) {
	 service.fundTransfer(mobNo1, mobNo2, amt);
	 return "Transaction Successfull "+amt;
	}
}
