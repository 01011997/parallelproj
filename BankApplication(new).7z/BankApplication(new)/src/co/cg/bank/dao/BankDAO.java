package co.cg.bank.dao;

import java.util.Map;

import co.cg.bank.bean.Bank;

public interface BankDAO {

	int checkBalance(int check_no);

	int deposit(int accountno1, int amount);

	int withdraw(int account2, int amount1);
	public void addNewAccount(Bank bank);

	public Map<Integer, Bank> displayAccountDetails();

	String fundTransfer(int sender_no, int recipient_no, int transferamount);
}
