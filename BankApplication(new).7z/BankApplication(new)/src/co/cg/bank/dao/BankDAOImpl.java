package co.cg.bank.dao;

import java.util.HashMap;
import java.util.Map;
import co.cg.bank.bean.Bank;

public class BankDAOImpl implements BankDAO {

	public static Map<Integer, Bank> bank = new  HashMap<Integer,Bank>();

	public void addNewAccount(Bank bank1)
	{
		bank.put(bank1.getAccountno(), bank1);
		System.out.println(bank);
	}
	public Map<Integer,Bank> displayAccountDetails()
	{
		return bank;
	}
	
	@Override
	public int checkBalance(int check_no) {

		int displayBalance = 0;
		for(Bank b:bank.values())
		{
			if(b.getAccountno()==check_no)
			{
				displayBalance = b.getBalance();
				break;
			}
			else
				System.out.println("Please Enter proper Account Number");
		}

		return displayBalance;
	}

	
	@Override
	public int deposit(int accountno1, int amount) {
		int amountAfterDeposit = 0;
		for(Bank b:bank.values())
		{
			System.out.println("Account Number:" +b.getAccountno());
			
			int currentBalance = b.getBalance();
			
			 if(b.getAccountno()==accountno1)
			{
				amountAfterDeposit = b.getBalance()+amount;
				b.setBalance(amountAfterDeposit);
				break;
			}
			else
				System.out.println("Please Enter proper Account Number");
		}
		return amountAfterDeposit;
	}
	
	
	public int withdraw(int checkno1, int amount1)
	{
	int amountAfterWithdraw = 0;
	for(Bank b:bank.values())
	{
		System.out.println("Account Number:" +b.getAccountno());
		
		int currentBalance = b.getBalance();
		
		if(currentBalance <amount1)
		{
			System.out.println("You don't have enough balance");
		}
		else if(b.getAccountno()==checkno1)
		{
			amountAfterWithdraw = b.getBalance()-amount1;
			b.setBalance(amountAfterWithdraw);
			break;
		}
		else
			System.out.println("Please Enter proper Account Number");
	}
	return amountAfterWithdraw;

}
	@Override
	public String fundTransfer(int sender_no, int recipient_no, int transferamount) {
		int amountAfterWithdraw;
		int amountAfterDeposit;
		boolean accountFlag = false;
		for(Bank acc:bank.values()) {
			if(acc.getAccountno()==sender_no) {
				 amountAfterWithdraw=acc.getBalance()-transferamount;
				acc.setBalance( amountAfterWithdraw);
				accountFlag = false;
				break;
			}
			else{
				accountFlag = true;
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		for(Bank acc:bank.values()) {
				amountAfterDeposit = acc.getBalance()+transferamount;
				acc.setBalance(amountAfterDeposit);
				accountFlag = false;

				break;
			
			/*else {
				accountFlag = true;
				System.out.println("Enter Proper Account Number");
			}*/
		}
		return "Amount Transfered";
	}

	
}
