package co.cg.bank.service;

import java.util.Map;
import java.util.regex.Pattern;

import co.cg.bank.bean.Bank;
import co.cg.bank.dao.BankDAO;
import co.cg.bank.dao.BankDAOImpl;
import co.cg.bank.exception.BankException;

public class BankServiceImpl implements BankService {

	BankDAO dao = new BankDAOImpl();
	@Override
	public void validateName(String name) throws BankException {
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, name) == false) {
			throw new BankException("name should contain only alphabets");
	}
	}

	@Override
	public void validateMobile(String mobno) throws BankException {
		String phoneRegEx = "[7|8|9]{1}[0-9]{9}";
		if (Pattern.matches(phoneRegEx, mobno) == false) {
			throw new BankException("mobile number should contain exactly 10 digits and should start with 7,8,9 ");
		}		
	}

	@Override
	public void validateAadhar(String aadharno) throws BankException {
		String aadharRegEx = "[0-9]{12}";
		if (Pattern.matches(aadharRegEx, aadharno) == false) {
			throw new BankException("Aadhar number should contain exactly 12 digits");
		}	
	}

	@Override
	public int checkBalance(int check_no) {
		return dao.checkBalance(check_no);
	}

	@Override
	public int deposit(int accountno1, int amount) {
		return dao.deposit(accountno1, amount);
	}

	@Override
	public int withdraw(int account2, int amount1) {
		return dao.withdraw(account2,amount1);
	}

	@Override
	public Map<Integer, Bank> displayAccountDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addNewAccount(Bank bank) {
		dao.addNewAccount(bank);
	}

	@Override
	public String fundTransfer(int sender_no, int recipient_no, int transferamount) {
		String transfer = dao.fundTransfer(sender_no, recipient_no, transferamount);
		return transfer;
	}

	/*@Override
	public int deposit(int accountno1, int amount) {
		return dao.deposit(accountno1,amount);
	}*/
}
