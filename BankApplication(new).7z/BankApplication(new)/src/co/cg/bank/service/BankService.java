package co.cg.bank.service;

import java.util.Map;

import co.cg.bank.bean.Bank;
import co.cg.bank.exception.BankException;

public interface BankService {

	void validateName(String name) throws BankException;

	void validateMobile(String mobno) throws BankException;

	void validateAadhar(String aadharno) throws BankException;

	int checkBalance(int check_no);

	int deposit(int accountno1, int amount);

	int withdraw(int account2, int amount1);
	Map<Integer,Bank>displayAccountDetails();
	public void addNewAccount(Bank bank) ;

	String fundTransfer(int sender_no, int recipient_no, int transferamount);
}
